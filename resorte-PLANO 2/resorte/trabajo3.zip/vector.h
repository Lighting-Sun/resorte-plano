#pragma once
class vector
{
public:
	
	float p[3];
	
	vector(float x = 0, float y = 0, float z = 0);

	~vector();
};

