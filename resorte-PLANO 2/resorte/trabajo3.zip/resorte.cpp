#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <windows.h>
#include <string.h>
#include <stdio.h>
#include "vector.h"
#include "particula.h"
#ifdef _WIN32
#include "glut.h"
#elif defined(__APPLE__)
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
using namespace std;
float r = 5, t = 0, g[3] = { 0, -9.8, 0 }, m = 10, h = 0.1, Kd = 1, Ks = 3, d = 0;
int i;
double movZ = 0;
double movY = 0;
double giro = 0;
double giro2 = 0;
/***********************************/
class punto {
public:
	punto(float x = 0.0, float y = 0.0, float z = 0.0) :coordx(x), coordy(y), coordz(z) {}
	void mostrar();
	punto operator^(punto);//producto cruz
	punto operator-(punto);//resta
	float coordx, coordy, coordz;
};
punto P1, P2, P3, n, P1P2, P1P3;
punto punto::operator^(punto k) {   //producto cruz
	punto temp;
	temp.coordx = (coordy*k.coordz) - (k.coordy*coordz);
	temp.coordy = -((coordx*k.coordz) - (k.coordx*coordz));
	temp.coordz = (coordx*k.coordy) - (k.coordx*coordy);
	return temp;
}
punto punto::operator-(punto k) {   //producto cruz
	punto temp;
	temp.coordx = coordx - k.coordx;
	temp.coordy = coordy - k.coordy;
	temp.coordz = coordz - k.coordz;
	return temp;
}
void punto::mostrar() {
	cout << "(" << coordx << "," << coordy << "," << coordz << ")" << endl;
}

void Plano(punto n, punto p, float d){
	float x, y, z;
	x = p.coordx - 50;
	z = p.coordz - 50;
	y = -(d + (n.coordx*x) + (n.coordz*z)) / n.coordy;
	float x2, y2, z2;
	x2 = p.coordx + 50;
	z2 = p.coordz - 50;
	y2 = -(d + (n.coordx*x2) + (n.coordz*z2)) / n.coordy;
	float x3, y3, z3;
	x3 = p.coordx + 50;
	z3 = p.coordz + 50;
	y3 = -(d + (n.coordx*x3) + (n.coordz*z3)) / n.coordy;
	float x4, y4, z4;
	x4 = p.coordx - 50;
	z4 = p.coordz + 50;
	y4 = -(d + (n.coordx*x4) + (n.coordz*z4)) / n.coordy;
	glColor4ub(255, 255, 255, 100);
	glBegin(GL_QUADS);
	glVertex3f(x, y, z);
	glVertex3f(x2, y2, z2);
	glVertex3f(x3, y3, z3);
	glVertex3f(x4, y4, z4);
	glEnd();
}
void Triangulo(punto p1, punto p2, punto p3){
	glBegin(GL_TRIANGLES);
	glColor4ub(255, 0, 0, 255);
	glVertex3f(p1.coordx, p1.coordy, p1.coordz);
	glColor4ub(0, 255, 0, 255);
	glVertex3f(p2.coordx, p2.coordy, p2.coordz);
	glColor4ub(0, 0, 255, 255);
	glVertex3f(p3.coordx, p3.coordy, p3.coordz);
	glEnd();
}
/***********************************/
void TransformacionesCamara();
void IniciarCG(){
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-300, 300, -300, 300, -300, 300);
	glMatrixMode(GL_MODELVIEW);
}
vector pos = { 0, 100, 77.94f };
vector pos2 = { 45, 100, 0 };
vector pos3 = { -45, 100, 0 };
vector vel = { 0, 0, 0 };
vector vel2 = { 0, -100, 100 };
particula part(pos, vel, m, r);
particula part2(pos2, vel, m, r);
particula part3(pos3, vel, m, r);
vector va = { 0, 150, 77.94f };
vector va2 = { 45, 150, 0 };
vector va3 = { -45, 150, 0 };
particula ancla(va, vel, m, r);
particula ancla2(va2, vel, m, r);
particula ancla3(va3, vel, m, r);
void TransformacionesCamara(){
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(30, 1, 0.001, 10000);
	glTranslated(0, movY, movZ);
	gluLookAt(400, 400, 400, 0, 0, 0, 0, 1, 0);
	glMatrixMode(GL_MODELVIEW);
}
void ejes(){
	glLineWidth(4);
	glBegin(GL_LINES);
	glColor3f(0.0, 1.0, 0.0);
	glVertex3d(0, -180, 0);
	glVertex3d(0, 180, 0);
	glColor3f(0.0, 0.0, 1.0);
	glVertex3d(0, 0, -180);
	glVertex3d(0, 0, 180);
	glColor3f(1.0, 0.0, 0.0);
	glVertex3d(-180, 0, 0);
	glVertex3d(180, 0, 0);
	glEnd();
}
void Graficar(){
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glEnable(GL_DEPTH_TEST);
	glLoadIdentity();
	glRotated(giro, 0, 1, 0);
	TransformacionesCamara();
	ejes();
	glPushMatrix();
	glTranslatef(part.posicion.p[0], part.posicion.p[1], part.posicion.p[2]);
	part.pintar();
	glFlush();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(part2.posicion.p[0], part2.posicion.p[1], part2.posicion.p[2]);
	part2.pintar();
	glFlush();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(part3.posicion.p[0], part3.posicion.p[1], part3.posicion.p[2]);
	part3.pintar();
	glFlush();
	glPopMatrix();
	Plano(n, P1, d);//grafica el plano
	Triangulo(P1, P2, P3);
	part.enlace(ancla, part);
	part2.enlace(ancla2, part2);
	part3.enlace(ancla3, part3);
	part.enlace(part2, part);
	part2.enlace(part3, part2);
	part3.enlace(part, part3);
	glutSwapBuffers();
}

void OnKey(unsigned char key, int x, int y){
	switch (key)
	{
	case 'i': case 'I':
		movZ += 1;
		break;
	case 'k': case 'K':
		movZ -= 1;
		break;
	case 'o': case 'O':
		movY += 0.4f;
		break;
	case 'l': case 'L':
		movY -= 0.4f;
		break;
	case 'a': case 'A':
		giro += 0.4f;
		break;
	case 'd': case 'D':
		giro -= 0.4f;
		break;
	case 's': case 'S':
		giro2 -= 0.4f;
		break;
	}
	if (key == 27)
		exit(0);
	if (key == '1')
		part.Fuerza.p[1] += -200;
	if (key == '2')
		part2.Fuerza.p[1] += -200;
	if (key == '3')
		part3.Fuerza.p[1] += -200;
}


void calc(){
	part.Calcular_fa(ancla);
	part.Calcular_Resorte(Kd, Ks);
	part.Calcular_fa(part2);
	part.Calcular_Resorte(Kd, Ks);
	part.Calcular_fa(part3);
	part.Calcular_Resorte(Kd, Ks);
	part.Calcular_Fuerza(g, Kd, Ks, h);
}

void calc2(){
	part2.Calcular_fa(ancla2);
	part2.Calcular_Resorte(Kd, Ks);
	part2.Calcular_fa(part);
	part2.Calcular_Resorte(Kd, Ks);
	part2.Calcular_fa(part3);
	part2.Calcular_Resorte(Kd, Ks);
	part2.Calcular_Fuerza(g, Kd, Ks, h);
}
void calc3(){
	part3.Calcular_fa(ancla3);
	part3.Calcular_Resorte(Kd, Ks);
	part3.Calcular_fa(part2);
	part3.Calcular_Resorte(Kd, Ks);
	part3.Calcular_fa(part);
	part3.Calcular_Resorte(Kd, Ks);
	part3.Calcular_Fuerza(g, Kd, Ks, h);
}
void OnTimerGL(int id){
	calc();
	calc2();
	calc3();
	P1.coordx = part.posicion.p[0];
	P1.coordy = part.posicion.p[1];
	P1.coordz = part.posicion.p[2];
	P2.coordx = part2.posicion.p[0];
	P2.coordy = part2.posicion.p[1];
	P2.coordz = part2.posicion.p[2];
	P3.coordx = part3.posicion.p[0];
	P3.coordy = part3.posicion.p[1];
	P3.coordz = part3.posicion.p[2];
	P1P2 = P2 - P1;
	P1P3 = P3 - P1;
	n = P1P2^P1P3;
	cout << "Vector normal:";
	n.mostrar();
	d = -n.coordx*P2.coordx - n.coordy*P2.coordy - n.coordz*P2.coordz;
	cout << "valor de d: " << d;
	glutPostRedisplay();
	glutTimerFunc(10, OnTimerGL, 1);
	t += h;
}

int main(int argc, char **argv){
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 800);
	glutInit(&argc, argv);
	glutInitWindowPosition(200, 200);
	glutCreateWindow("Programa Basico");
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glutKeyboardFunc(OnKey);
	IniciarCG();
	glutDisplayFunc(Graficar);
	glutTimerFunc(1, OnTimerGL, 1);
	glutMainLoop();
	system("pause");
	return 0;
}