#include "vector.h"

vector::vector(float x, float y, float z)
{
	p[0] = x;
	p[1] = y;
	p[2] = z;
}


vector::~vector()
{
}
